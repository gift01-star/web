
// Shared geolocation logic can be added here if needed in the future.
